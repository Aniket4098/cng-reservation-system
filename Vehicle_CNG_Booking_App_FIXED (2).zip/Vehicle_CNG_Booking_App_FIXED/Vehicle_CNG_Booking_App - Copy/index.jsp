<%@ page language="java" %>
<html>
<head><title>CNG Booking</title></head>
<body>
<h2>Vehicle CNG Booking App Running ✅</h2>
<a href="Login.jsp">Login</a>
</body>
</html>
