package CngBooking;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;



import com.DbConnection.DBConnection;
import org.json.JSONArray;
import org.json.JSONObject;


public class PumpDataServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {

        response.setContentType("application/json");
        PrintWriter out = response.getWriter();

        try (Connection con = DBConnection.connect()) {
            // Try cng_pumps first (newer table structure)
            String query = "SELECT pump_id, pump_name, latitude, longitude, city, address, mobileNo, price_per_kg, status FROM cng_pumps";
            PreparedStatement pst = null;
            ResultSet rs = null;
            
            try {
                pst = con.prepareStatement(query);
                rs = pst.executeQuery();
            } catch (SQLException e) {
                // If cng_pumps doesn't exist, try cng_pump (older structure)
                try {
                    if (rs != null) rs.close();
                    if (pst != null) pst.close();
                } catch (SQLException closeEx) {
                    // Ignore close errors
                }
                query = "SELECT cng_id, pump_name, latitude, longitude, city, address, mobileNo, price_per_kg, status FROM cng_pump";
                pst = con.prepareStatement(query);
                rs = pst.executeQuery();
            }

            JSONArray pumpsArray = new JSONArray();

            while (rs.next()) {
                JSONObject pump = new JSONObject();
                try {
                    // Try pump_id first (cng_pumps), fallback to cng_id (cng_pump)
                    pump.put("id", rs.getInt("pump_id"));
                } catch (SQLException e) {
                    pump.put("id", rs.getInt("cng_id"));
                }
                pump.put("name", rs.getString("pump_name"));
                pump.put("lat", rs.getDouble("latitude"));
                pump.put("lng", rs.getDouble("longitude"));
                pump.put("city", rs.getString("city"));
                pump.put("address", rs.getString("address"));
                pump.put("phone", rs.getString("mobileNo"));
                
                // Add price if available
                try {
                    Object price = rs.getObject("price_per_kg");
                    pump.put("price_per_kg", price != null ? price.toString() : "N/A");
                } catch (SQLException e) {
                    pump.put("price_per_kg", "N/A");
                }
                
                // Add status if available
                try {
                    String status = rs.getString("status");
                    pump.put("status", status != null ? status : "UNKNOWN");
                } catch (SQLException e) {
                    pump.put("status", "UNKNOWN");
                }

                pumpsArray.put(pump);
            }
            
            if (rs != null) rs.close();
            if (pst != null) pst.close();

            out.print(pumpsArray.toString());

        } catch (Exception e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"error\":\"" + e.getMessage() + "\"}");
        }
    }
}
