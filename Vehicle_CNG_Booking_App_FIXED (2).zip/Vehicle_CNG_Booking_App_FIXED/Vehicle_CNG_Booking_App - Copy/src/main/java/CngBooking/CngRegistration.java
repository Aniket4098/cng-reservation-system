package CngBooking;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.DbConnection.DBConnection;

public class CngRegistration extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String pumpName  = request.getParameter("pname");
        String address   = request.getParameter("address");
        String city      = request.getParameter("city");
        String taluka    = request.getParameter("taluka");
        String district  = request.getParameter("district");
        String state     = request.getParameter("state");
        String mobile    = request.getParameter("mobile");
        String email     = request.getParameter("email");      // ← email field
        String password  = request.getParameter("pwd");
        String price     = request.getParameter("price_per_kg");
        String openTime  = request.getParameter("open_time");
        String closeTime = request.getParameter("close_time");
        String latStr    = request.getParameter("latitude");
        String lngStr    = request.getParameter("longitude");

        Connection con = null;
        try {
            con = DBConnection.connect();
            if (con == null) {
                response.sendRedirect("Login.jsp?error=Database+connection+failed");
                return;
            }

            // FIX: "email" was missing from the column list below, yet the old code
            // still called pst.setString(12, email) - which actually landed in the
            // "latitude" slot - and then called pst.setDouble/setNull(14, ...) even
            // though the query only ever had 13 "?" placeholders. That always threw
            // "Parameter index out of range (14 > number of parameters, which is 13)",
            // so EVERY seller registration failed silently and no row was ever saved.
            PreparedStatement pst = con.prepareStatement(
            		"INSERT INTO cng_pumps(" +
            		"pump_name,address,city,taluka,district,state," +
            		"mobileNo,email,password,price_per_kg,open_time,close_time," +
            		"latitude,longitude,cng_kg,status)" +
            		" VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,1000,'PENDING')"
            		);
            pst.setString(1, pumpName);
            pst.setString(2, address);
            pst.setString(3, city);
            pst.setString(4, taluka != null ? taluka : "");
            pst.setString(5, district);
            pst.setString(6, state);
            pst.setString(7, mobile);
            pst.setString(8, email);
            pst.setString(9, password);
            pst.setString(10, price != null ? price : "85.00");
            pst.setString(11, openTime != null ? openTime : "06:00");
            pst.setString(12, closeTime != null ? closeTime : "22:00");
            if (latStr != null && !latStr.isEmpty()) pst.setDouble(13, Double.parseDouble(latStr));
            else pst.setNull(13, java.sql.Types.DOUBLE);
            if (lngStr != null && !lngStr.isEmpty()) pst.setDouble(14, Double.parseDouble(lngStr));
            else pst.setNull(14, java.sql.Types.DOUBLE);

            pst.executeUpdate();
            pst.close();
            response.sendRedirect("Login.jsp?msg=Registration+successful!+Wait+for+Admin+Approval.");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("Login.jsp?error=Registration+failed");
        } finally {
            try { if (con != null) con.close(); } catch (Exception ignored) {}
        }
    }
}
