package CngBooking;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.DbConnection.DBConnection;

public class DownloadReceipt extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userId") == null) {
            response.sendRedirect("Login.jsp?error=Please login first");
            return;
        }

        int userId = (int) session.getAttribute("userId");
        String bookingIdStr = request.getParameter("bookingId");

        if (bookingIdStr == null || bookingIdStr.trim().isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Booking ID is required");
            return;
        }

        int bookingId;
        try {
            bookingId = Integer.parseInt(bookingIdStr);
        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid booking ID");
            return;
        }

        Connection con = null;
        try {
            con = DBConnection.connect();
            if (con == null) {
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Database connection failed");
                return;
            }

            String query = "SELECT sb.booking_id, sb.pump_id, sb.booking_date, sb.slot_time, " +
                    "sb.vehicle_type, sb.vehicle_number, sb.status, sb.created_at, " +
                    "sb.full_name, sb.phone, sb.email, " +
                    "cp.pump_name, cp.address, cp.city " +
                    "FROM slot_bookings sb " +
                    "LEFT JOIN cng_pumps cp ON sb.pump_id = cp.pump_id " +
                    "WHERE sb.booking_id = ? AND sb.user_id = ?";

            PreparedStatement pst = con.prepareStatement(query);
            pst.setInt(1, bookingId);
            pst.setInt(2, userId);
            ResultSet rs = pst.executeQuery();

            if (!rs.next()) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Booking not found");
                rs.close(); pst.close();
                return;
            }

            // Build QR code data string
            String pumpName   = rs.getString("pump_name")   != null ? rs.getString("pump_name")   : "Station #" + rs.getInt("pump_id");
            String city       = rs.getString("city")        != null ? rs.getString("city")        : "";
            String address    = rs.getString("address")     != null ? rs.getString("address")     : "";
            String bookDate   = String.valueOf(rs.getDate("booking_date"));
            String slotTime   = rs.getString("slot_time")   != null ? rs.getString("slot_time")   : "";
            String vehType    = rs.getString("vehicle_type")   != null ? rs.getString("vehicle_type")   : "N/A";
            String vehNum     = rs.getString("vehicle_number") != null ? rs.getString("vehicle_number") : "N/A";
            String custName   = rs.getString("full_name")   != null ? rs.getString("full_name")   : "N/A";
            String custPhone  = rs.getString("phone")       != null ? rs.getString("phone")       : "N/A";
            String custEmail  = rs.getString("email")       != null ? rs.getString("email")       : "N/A";
            String status     = rs.getString("status")      != null ? rs.getString("status")      : "CONFIRMED";
            String createdAt  = rs.getTimestamp("created_at") != null
                    ? new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(rs.getTimestamp("created_at")) : "N/A";

            // QR code content — compact booking summary
            String upiId = "8421759845@kotakbank";   // <-- Change this
            double amount = 41.30;

            String qrData = "BOOKING:" + bookingId
            		  + "|NAME:" + custName
            		  + "|PHONE:" + custPhone
            		  + "|VEH:" + vehNum
            		  + "|DATE:" + bookDate
            		  + "|SLOT:" + slotTime
            		  + "|PUMP:" + pumpName;
            		String qrEncoded = URLEncoder.encode(qrData, "UTF-8");
            		String qrUrl = "https://chart.googleapis.com/chart?chs=250x250&cht=qr&chl=" + qrEncoded + "&choe=UTF-8";
            // Send as downloadable HTML
            response.setContentType("text/html; charset=UTF-8");
            response.setHeader("Content-Disposition", "attachment; filename=receipt_" + bookingId + ".html");

            PrintWriter out = response.getWriter();

            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<meta charset='UTF-8'>");
            out.println("<title>Booking Receipt #" + bookingId + "</title>");
            out.println("<style>");
            out.println("body{font-family:Arial,sans-serif;margin:0;background:#0b0f19;color:#e5e5e5;display:flex;justify-content:center;align-items:flex-start;padding:30px;}");
            out.println(".receipt{background:#111827;padding:36px;max-width:620px;width:100%;border-radius:14px;box-shadow:0 0 30px rgba(0,255,102,0.15);}");
            out.println(".header{text-align:center;border-bottom:2px solid #00ff66;padding-bottom:20px;margin-bottom:24px;}");
            out.println(".header h1{color:#00ff66;font-size:2rem;margin:0;letter-spacing:2px;}");
            out.println(".header p{color:#9ca3af;margin:6px 0 0;}");
            out.println(".badge{display:inline-block;background:#00ff66;color:#111;padding:4px 14px;border-radius:20px;font-size:0.85rem;font-weight:bold;margin-top:8px;}");
            out.println(".details{margin:20px 0;}");
            out.println(".detail-row{display:flex;justify-content:space-between;padding:10px 0;border-bottom:1px solid #1f2937;}");
            out.println(".detail-label{font-weight:bold;color:#9ca3af;font-size:0.9rem;}");
            out.println(".detail-value{color:#e5e5e5;font-size:0.9rem;text-align:right;max-width:60%;}");
            out.println(".qr-section{text-align:center;margin:28px 0 10px;}");
            out.println(".qr-section p{color:#9ca3af;font-size:0.85rem;margin-top:10px;}");
            out.println(".qr-section img{border:4px solid #00ff66;border-radius:10px;padding:6px;background:#fff;}");
            out.println(".footer{text-align:center;margin-top:24px;color:#6b7280;font-size:0.78rem;border-top:1px solid #1f2937;padding-top:16px;}");
            out.println("@media print{body{background:white;} .receipt{box-shadow:none;background:white;color:#111;} .detail-label{color:#555;} .detail-value{color:#111;} .header h1{color:#00aa44;} .footer{color:#888;}}");
            out.println("</style>");
            out.println("</head>");
            out.println("<body>");
            out.println("<div class='receipt'>");

            // Header
            out.println("<div class='header'>");
            out.println("<h1>&#9889; BookMyCNG</h1>");
            out.println("<p>CNG Slot Booking Receipt</p>");
            out.println("<span class='badge'>&#10003; " + status + "</span>");
            out.println("</div>");

            // Booking details
            out.println("<div class='details'>");
            out.println("<div class='detail-row'><span class='detail-label'>Receipt Number</span><span class='detail-value'>#" + bookingId + "</span></div>");
            out.println("<div class='detail-row'><span class='detail-label'>Station</span><span class='detail-value'>" + pumpName + "</span></div>");
            out.println("<div class='detail-row'><span class='detail-label'>Address</span><span class='detail-value'>" + address + (city.isEmpty() ? "" : ", " + city) + "</span></div>");
            out.println("<div class='detail-row'><span class='detail-label'>Booking Date</span><span class='detail-value'>" + bookDate + "</span></div>");
            out.println("<div class='detail-row'><span class='detail-label'>Time Slot</span><span class='detail-value'>" + slotTime + "</span></div>");
            out.println("<div class='detail-row'><span class='detail-label'>Vehicle Type</span><span class='detail-value'>" + vehType + "</span></div>");
            out.println("<div class='detail-row'><span class='detail-label'>Vehicle Number</span><span class='detail-value'>" + vehNum + "</span></div>");
            out.println("<div class='detail-row'><span class='detail-label'>Customer Name</span><span class='detail-value'>" + custName + "</span></div>");
            out.println("<div class='detail-row'><span class='detail-label'>Phone</span><span class='detail-value'>" + custPhone + "</span></div>");
            out.println("<div class='detail-row'><span class='detail-label'>Email</span><span class='detail-value'>" + custEmail + "</span></div>");
            out.println("<div class='detail-row'><span class='detail-label'>Booking Created</span><span class='detail-value'>" + createdAt + "</span></div>");
            out.println("</div>");

            // QR Code section
            out.println("<div class='qr-section'>");
            out.println("<img src='" + qrUrl + "' alt='Booking QR Code' width='200' height='200'/>");
            out.println("<p>Scan this QR code at the station to verify your booking</p>");
            out.println("</div>");

            // Footer
            out.println("<div class='footer'>");
            out.println("<p>Thank you for using BookMyCNG! Please show this receipt at the CNG station.</p>");
            out.println("<p>Generated on: " + new SimpleDateFormat("dd MMM yyyy, hh:mm a").format(new Date()) + "</p>");
            out.println("</div>");

            out.println("</div>");
            out.println("</body>");
            out.println("</html>");

            rs.close();
            pst.close();

        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error generating receipt: " + e.getMessage());
        } finally {
            try { if (con != null) con.close(); } catch (Exception e) { e.printStackTrace(); }
        }
    }
}
